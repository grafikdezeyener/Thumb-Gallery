package com.thumbgallery.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.animation.DecelerateInterpolator
import androidx.appcompat.widget.AppCompatImageView

/**
 * ImageView with pinch-zoom, double-tap zoom and panning that cooperates with ViewPager2:
 * when zoomed it keeps the touch, and hands swipes back to the pager at the image edges.
 */
class ZoomImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : AppCompatImageView(context, attrs) {

    var onSingleTap: (() -> Unit)? = null

    // ImageView's constructor can call setImageDrawable before our fields exist.
    private var ready = false

    private val baseMatrix = Matrix()
    private val suppMatrix = Matrix()
    private val drawMatrix = Matrix()
    private val values = FloatArray(9)
    private val rect = RectF()
    private var animator: ValueAnimator? = null

    private val minScale = 1f
    private val maxScale = 6f
    private val doubleTapScale = 2.5f

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val current = currentScale()
                val target = (current * detector.scaleFactor).coerceIn(minScale, maxScale)
                val factor = target / current
                suppMatrix.postScale(factor, factor, detector.focusX, detector.focusY)
                applyMatrix()
                return true
            }
        })

    private val gestureDetector = GestureDetector(context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onSingleTap?.invoke()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val target = if (isZoomed()) minScale else doubleTapScale
                animateScaleTo(target, e.x, e.y)
                return true
            }

            override fun onScroll(
                e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float,
            ): Boolean {
                if (!isZoomed() || scaleDetector.isInProgress) return false
                suppMatrix.postTranslate(-distanceX, -distanceY)
                applyMatrix()
                val r = displayRect() ?: return true
                val atLeft = r.left >= -1f
                val atRight = r.right <= width + 1f
                // Let the pager take over when dragging past an edge.
                if (e2.pointerCount == 1 &&
                    ((distanceX < 0 && atLeft) || (distanceX > 0 && atRight))
                ) {
                    parent?.requestDisallowInterceptTouchEvent(false)
                }
                return true
            }
        })

    init {
        ready = true
        scaleType = ScaleType.MATRIX
    }

    override fun setImageDrawable(drawable: Drawable?) {
        super.setImageDrawable(drawable)
        if (ready) resetZoom()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        resetZoom()
    }

    fun isZoomed() = currentScale() > minScale + 0.01f

    fun resetZoom() {
        animator?.cancel()
        val d = drawable
        if (d == null || width == 0 || height == 0 ||
            d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0
        ) {
            suppMatrix.reset()
            return
        }
        baseMatrix.setRectToRect(
            RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat()),
            RectF(0f, 0f, width.toFloat(), height.toFloat()),
            Matrix.ScaleToFit.CENTER,
        )
        suppMatrix.reset()
        applyMatrix()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN && isZoomed()) {
            parent?.requestDisallowInterceptTouchEvent(true)
        }
        if (event.pointerCount > 1) {
            parent?.requestDisallowInterceptTouchEvent(true)
        }
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        return true
    }

    private fun currentScale(): Float {
        suppMatrix.getValues(values)
        return values[Matrix.MSCALE_X]
    }

    private fun displayRect(): RectF? {
        val d = drawable ?: return null
        rect.set(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        drawMatrix.mapRect(rect)
        return rect
    }

    private fun computeDrawMatrix() {
        drawMatrix.set(baseMatrix)
        drawMatrix.postConcat(suppMatrix)
    }

    private fun applyMatrix() {
        computeDrawMatrix()
        val r = displayRect()
        if (r != null) {
            val vw = width.toFloat()
            val vh = height.toFloat()
            val dx = when {
                r.width() <= vw -> (vw - r.width()) / 2f - r.left
                r.left > 0f -> -r.left
                r.right < vw -> vw - r.right
                else -> 0f
            }
            val dy = when {
                r.height() <= vh -> (vh - r.height()) / 2f - r.top
                r.top > 0f -> -r.top
                r.bottom < vh -> vh - r.bottom
                else -> 0f
            }
            if (dx != 0f || dy != 0f) {
                suppMatrix.postTranslate(dx, dy)
                computeDrawMatrix()
            }
        }
        imageMatrix = drawMatrix
    }

    private fun animateScaleTo(target: Float, fx: Float, fy: Float) {
        animator?.cancel()
        val start = currentScale()
        animator = ValueAnimator.ofFloat(start, target).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val next = it.animatedValue as Float
                val factor = next / currentScale()
                suppMatrix.postScale(factor, factor, fx, fy)
                applyMatrix()
            }
            start()
        }
    }
}
