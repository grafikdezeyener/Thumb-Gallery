package com.thumbgallery.app

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

/** Grid of square thumbnails on the main screen. */
class GridAdapter(
    private val onClick: (position: Int) -> Unit,
) : RecyclerView.Adapter<GridAdapter.VH>() {

    var items: List<MediaItem> = emptyList()
        private set

    /** Pixel size thumbnails are decoded at (bucketed so resizing doesn't thrash the cache). */
    var decodePx: Int = 256

    class VH(val root: ViewGroup, val image: ImageView) : RecyclerView.ViewHolder(root)

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<MediaItem>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_grid, parent, false) as ViewGroup
        val holder = VH(v, v.findViewById(R.id.image))
        v.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClick(pos)
        }
        return holder
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        ImageLoader.loadThumbnail(holder.image, items[position].uri, decodePx)
    }
}

/** Full-screen pages for the viewer's ViewPager2. */
class ViewerPagerAdapter(
    private val maxSidePx: Int,
    private val onTap: () -> Unit,
) : RecyclerView.Adapter<ViewerPagerAdapter.VH>() {

    var items: List<MediaItem> = emptyList()
        private set

    class VH(val image: ZoomImageView) : RecyclerView.ViewHolder(image)

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<MediaItem>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = ZoomImageView(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
        }
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.image.onSingleTap = onTap
        ImageLoader.loadFull(holder.image, items[position].uri, maxSidePx)
    }

    override fun onViewRecycled(holder: VH) {
        holder.image.resetZoom()
    }
}

/** The resizable thumbnail strip at the bottom of the viewer. */
class ThumbStripAdapter(
    itemSizePx: Int,
    private val decodePx: Int,
    private val onClick: (position: Int) -> Unit,
) : RecyclerView.Adapter<ThumbStripAdapter.VH>() {

    companion object {
        private const val PAYLOAD_SIZE = "size"
        private const val PAYLOAD_SELECTION = "selection"
    }

    var items: List<MediaItem> = emptyList()
        private set

    var itemSizePx: Int = itemSizePx
        private set

    var selected: Int = -1
        private set

    class VH(val root: ViewGroup, val image: ImageView) : RecyclerView.ViewHolder(root)

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<MediaItem>) {
        items = list
        notifyDataSetChanged()
    }

    fun setSelected(position: Int) {
        if (position == selected) return
        val old = selected
        selected = position
        if (old in items.indices) notifyItemChanged(old, PAYLOAD_SELECTION)
        if (position in items.indices) notifyItemChanged(position, PAYLOAD_SELECTION)
    }

    /** Resizes every thumbnail without reloading images. */
    fun setItemSize(px: Int) {
        if (px == itemSizePx) return
        itemSizePx = px
        notifyItemRangeChanged(0, itemCount, PAYLOAD_SIZE)
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_strip_thumb, parent, false) as ViewGroup
        val holder = VH(v, v.findViewById(R.id.image))
        v.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClick(pos)
        }
        return holder
    }

    override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isEmpty()) {
            onBindViewHolder(holder, position)
            return
        }
        if (payloads.contains(PAYLOAD_SIZE)) applySize(holder)
        if (payloads.contains(PAYLOAD_SELECTION)) applySelection(holder, position)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        applySize(holder)
        applySelection(holder, position)
        ImageLoader.loadThumbnail(holder.image, items[position].uri, decodePx)
    }

    private fun applySize(holder: VH) {
        val lp = holder.root.layoutParams
        if (lp.width != itemSizePx || lp.height != itemSizePx) {
            lp.width = itemSizePx
            lp.height = itemSizePx
            holder.root.layoutParams = lp
        }
    }

    private fun applySelection(holder: VH, position: Int) {
        val isSel = position == selected
        holder.root.isSelected = isSel
        holder.image.alpha = if (isSel) 1f else 0.65f
    }
}
