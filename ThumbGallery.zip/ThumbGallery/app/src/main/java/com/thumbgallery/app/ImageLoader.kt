package com.thumbgallery.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import android.widget.ImageView
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Small dependency-free image loader with memory caches.
 * Thumbnails and full-screen images use separate caches and thread pools so a
 * fast scroll through the grid never blocks the image you are viewing.
 */
object ImageLoader {

    private val maxMem = Runtime.getRuntime().maxMemory()

    private val thumbCache = object : LruCache<String, Bitmap>((maxMem / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.allocationByteCount
    }
    private val fullCache = object : LruCache<String, Bitmap>((maxMem / 6).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.allocationByteCount
    }

    private val thumbPool: ExecutorService = Executors.newFixedThreadPool(4)
    private val fullPool: ExecutorService = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun loadThumbnail(view: ImageView, uri: Uri, sizePx: Int) =
        load(view, uri, sizePx, thumbnail = true)

    fun loadFull(view: ImageView, uri: Uri, maxSidePx: Int) =
        load(view, uri, maxSidePx, thumbnail = false)

    private fun load(view: ImageView, uri: Uri, targetPx: Int, thumbnail: Boolean) {
        val key = "${if (thumbnail) "t" else "f"}|$uri|$targetPx"
        val cache = if (thumbnail) thumbCache else fullCache
        view.setTag(R.id.tag_image_key, key)

        val cached = cache.get(key)
        if (cached != null) {
            view.setImageBitmap(cached)
            return
        }
        view.setImageDrawable(null)

        val appContext = view.context.applicationContext
        val pool = if (thumbnail) thumbPool else fullPool
        pool.execute {
            // Skip work for views that were recycled before we got to them.
            if (view.getTag(R.id.tag_image_key) != key) return@execute
            val bmp = try {
                decode(appContext, uri, targetPx, thumbnail)
            } catch (_: Exception) {
                null
            } catch (_: OutOfMemoryError) {
                null
            }
            if (bmp != null) cache.put(key, bmp)
            main.post {
                if (bmp != null && view.getTag(R.id.tag_image_key) == key) {
                    view.setImageBitmap(bmp)
                }
            }
        }
    }

    private fun decode(context: Context, uri: Uri, targetPx: Int, thumbnail: Boolean): Bitmap {
        if (thumbnail && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                // Uses the system thumbnail cache: very fast.
                return context.contentResolver.loadThumbnail(uri, Size(targetPx, targetPx), null)
            } catch (_: Exception) {
                // Fall through to a manual decode.
            }
        }
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        // ImageDecoder also applies EXIF rotation automatically.
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            val w = info.size.width
            val h = info.size.height
            var sample = 1
            if (thumbnail) {
                // Keep the short side >= target so center-crop stays sharp.
                while (w / (sample * 2) >= targetPx && h / (sample * 2) >= targetPx) sample *= 2
            } else {
                // Keep the long side >= screen size so zooming stays sharp,
                // but never exceed a GPU-friendly 4096px.
                while (maxOf(w, h) / (sample * 2) >= targetPx) sample *= 2
                while (maxOf(w, h) / sample > 4096) sample *= 2
            }
            decoder.setTargetSampleSize(sample)
        }
    }
}
