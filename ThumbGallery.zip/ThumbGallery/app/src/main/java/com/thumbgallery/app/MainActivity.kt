package com.thumbgallery.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PREF_COLUMNS = "grid_columns"
        private const val MIN_COLUMNS = 2
        private const val MAX_COLUMNS = 7
        private const val DEFAULT_COLUMNS = 3
    }

    private lateinit var grid: RecyclerView
    private lateinit var emptyView: View
    private lateinit var emptyText: TextView
    private lateinit var emptyButton: Button
    private lateinit var adapter: GridAdapter
    private lateinit var layoutManager: GridLayoutManager

    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var askedOnce = false
    private var loading = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            askedOnce = true
            refresh()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        grid = findViewById(R.id.grid)
        emptyView = findViewById(R.id.empty_view)
        emptyText = findViewById(R.id.empty_text)
        emptyButton = findViewById(R.id.empty_button)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            toolbar.updatePadding(top = bars.top, left = bars.left, right = bars.right)
            grid.updatePadding(left = bars.left, right = bars.right, bottom = bars.bottom)
            insets
        }

        adapter = GridAdapter { position ->
            val item = adapter.items[position]
            startActivity(
                Intent(this, ViewerActivity::class.java)
                    .putExtra(ViewerActivity.EXTRA_ID, item.id)
                    .putExtra(ViewerActivity.EXTRA_POSITION, position)
            )
        }
        layoutManager = GridLayoutManager(this, prefs.getInt(PREF_COLUMNS, DEFAULT_COLUMNS))
        grid.layoutManager = layoutManager
        grid.adapter = adapter
        grid.setHasFixedSize(true)
        grid.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateDecodeSize() }
        setupPinchToResize()

        emptyButton.setOnClickListener { onGrantClicked() }

        if (!hasPermission()) requestPermission()
    }

    override fun onResume() {
        super.onResume()
        refresh() // picks up new photos and permission changes made in Settings
    }

    // ---- Permissions -------------------------------------------------------

    private fun permissionsToRequest(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
        )
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun hasPermission() = permissionsToRequest().any { granted(it) }

    private fun hasPartialAccessOnly() = Build.VERSION.SDK_INT >= 34 &&
        !granted(Manifest.permission.READ_MEDIA_IMAGES) &&
        granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)

    private fun requestPermission() = permissionLauncher.launch(permissionsToRequest())

    private fun onGrantClicked() {
        val canAsk = permissionsToRequest().any { shouldShowRequestPermissionRationale(it) }
        if (askedOnce && !canAsk && !hasPermission()) {
            // Permanently denied: send the user to the app's settings page.
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.fromParts("package", packageName, null))
            )
        } else {
            requestPermission()
        }
    }

    // ---- Loading -----------------------------------------------------------

    private fun refresh() {
        invalidateOptionsMenu()
        if (!hasPermission()) {
            adapter.submit(emptyList())
            showEmpty(getString(R.string.permission_needed), getString(R.string.grant_access))
            return
        }
        if (loading) return
        loading = true
        thread {
            val list = MediaRepository.queryImages(this)
            runOnUiThread {
                loading = false
                if (isDestroyed) return@runOnUiThread
                if (list != adapter.items) adapter.submit(list)
                if (list.isEmpty()) {
                    showEmpty(getString(R.string.no_images), null)
                } else {
                    emptyView.visibility = View.GONE
                    grid.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun showEmpty(message: String, button: String?) {
        grid.visibility = View.GONE
        emptyView.visibility = View.VISIBLE
        emptyText.text = message
        emptyButton.visibility = if (button == null) View.GONE else View.VISIBLE
        if (button != null) emptyButton.text = button
    }

    // ---- Grid size ---------------------------------------------------------

    private fun setColumns(count: Int) {
        val c = count.coerceIn(MIN_COLUMNS, MAX_COLUMNS)
        if (c == layoutManager.spanCount) return
        layoutManager.spanCount = c
        prefs.edit().putInt(PREF_COLUMNS, c).apply()
        updateDecodeSize()
        adapter.notifyItemRangeChanged(0, adapter.itemCount)
    }

    private fun updateDecodeSize() {
        val w = grid.width
        if (w == 0) return
        val cell = w / layoutManager.spanCount
        // Round up to a 128px bucket, capped at 512.
        adapter.decodePx = (((cell + 127) / 128) * 128).coerceIn(128, 512)
    }

    private fun setupPinchToResize() {
        var accumulated = 1f
        val detector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                    accumulated = 1f
                    return true
                }

                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    accumulated *= detector.scaleFactor
                    if (accumulated > 1.25f) {
                        setColumns(layoutManager.spanCount - 1); accumulated = 1f
                    } else if (accumulated < 0.8f) {
                        setColumns(layoutManager.spanCount + 1); accumulated = 1f
                    }
                    return true
                }
            })
        grid.addOnItemTouchListener(object : RecyclerView.SimpleOnItemTouchListener() {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                detector.onTouchEvent(e)
                return e.pointerCount > 1 // take over two-finger gestures
            }

            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
                detector.onTouchEvent(e)
            }
        })
    }

    // ---- Menu --------------------------------------------------------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        menu.findItem(R.id.action_select_more)?.isVisible = hasPartialAccessOnly()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_bigger -> { setColumns(layoutManager.spanCount - 1); true }
        R.id.action_smaller -> { setColumns(layoutManager.spanCount + 1); true }
        R.id.action_select_more -> { requestPermission(); true }
        else -> super.onOptionsItemSelected(item)
    }
}
