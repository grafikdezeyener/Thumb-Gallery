package com.thumbgallery.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.roundToInt

class ViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "media_id"
        const val EXTRA_POSITION = "position"

        private const val PREF_THUMB_DP = "thumb_size_dp"
        private const val PREF_STRIP_VISIBLE = "strip_visible"
        const val MIN_THUMB_DP = 36
        const val MAX_THUMB_DP = 200
        const val DEFAULT_THUMB_DP = 72
    }

    private lateinit var pager: ViewPager2
    private lateinit var strip: RecyclerView
    private lateinit var stripLayout: LinearLayoutManager
    private lateinit var topBar: View
    private lateinit var bottomPanel: View
    private lateinit var stripContainer: View
    private lateinit var counter: TextView
    private lateinit var title: TextView
    private lateinit var sizeLabel: TextView

    private lateinit var pagerAdapter: ViewerPagerAdapter
    private lateinit var stripAdapter: ThumbStripAdapter

    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var uiVisible = true
    private var currentId = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)

        pager = findViewById(R.id.pager)
        strip = findViewById(R.id.thumb_strip)
        topBar = findViewById(R.id.top_bar)
        bottomPanel = findViewById(R.id.bottom_panel)
        stripContainer = findViewById(R.id.strip_container)
        counter = findViewById(R.id.counter)
        title = findViewById(R.id.title)
        sizeLabel = findViewById(R.id.size_label)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            topBar.updatePadding(top = bars.top, left = bars.left, right = bars.right)
            bottomPanel.updatePadding(bottom = bars.bottom, left = bars.left, right = bars.right)
            insets
        }

        findViewById<View>(R.id.btn_back).setOnClickListener { finish() }
        findViewById<View>(R.id.btn_size).setOnClickListener { showSizeDialog() }
        findViewById<View>(R.id.btn_toggle_strip).setOnClickListener {
            setStripVisible(stripContainer.visibility != View.VISIBLE)
        }

        // Full-screen pager
        val dm = resources.displayMetrics
        pagerAdapter = ViewerPagerAdapter(maxOf(dm.widthPixels, dm.heightPixels)) { toggleUi() }
        pager.adapter = pagerAdapter
        pager.offscreenPageLimit = 1

        // Thumbnail strip
        val thumbPx = dpToPx(prefs.getInt(PREF_THUMB_DP, DEFAULT_THUMB_DP))
        stripAdapter = ThumbStripAdapter(thumbPx, dpToPx(MAX_THUMB_DP).coerceAtMost(400)) { pos ->
            val smooth = abs(pos - pager.currentItem) <= 3
            pager.setCurrentItem(pos, smooth)
        }
        stripLayout = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        strip.layoutManager = stripLayout
        strip.adapter = stripAdapter
        strip.itemAnimator = null
        strip.clipToPadding = false
        strip.addOnLayoutChangeListener { _, left, _, right, _, oldLeft, _, oldRight, _ ->
            if (right - left != oldRight - oldLeft) {
                updateStripPadding()
                centerStrip(pager.currentItem, smooth = false)
            }
        }

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                stripAdapter.setSelected(position)
                centerStrip(position, smooth = true)
                updateHeader(position)
            }
        })

        setupResizeHandle()
        setStripVisible(prefs.getBoolean(PREF_STRIP_VISIBLE, true), save = false)
        updateSizeLabel()

        currentId = savedInstanceState?.getLong(EXTRA_ID, -1L)
            ?: intent.getLongExtra(EXTRA_ID, -1L)
        val fallbackPos = intent.getIntExtra(EXTRA_POSITION, 0)
        loadItems(fallbackPos)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        pagerAdapter.items.getOrNull(pager.currentItem)?.let { outState.putLong(EXTRA_ID, it.id) }
    }

    private fun loadItems(fallbackPos: Int) {
        thread {
            val list = MediaRepository.queryImages(this)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (list.isEmpty()) { finish(); return@runOnUiThread }
                pagerAdapter.submit(list)
                stripAdapter.submit(list)
                val start = list.indexOfFirst { it.id == currentId }
                    .takeIf { it >= 0 } ?: fallbackPos.coerceIn(0, list.lastIndex)
                pager.setCurrentItem(start, false)
                stripAdapter.setSelected(start)
                updateHeader(start)
                strip.post {
                    updateStripPadding()
                    centerStrip(start, smooth = false)
                }
            }
        }
    }

    private fun updateHeader(position: Int) {
        val items = pagerAdapter.items
        if (position !in items.indices) return
        counter.text = getString(R.string.counter_format, position + 1, items.size)
        title.text = items[position].name
    }

    // ---- Thumbnail strip sizing -------------------------------------------

    /** Drag the handle up to grow thumbnails, down to shrink. Double-tap resets. */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupResizeHandle() {
        val handle = findViewById<View>(R.id.resize_handle)
        val doubleTap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                setThumbSizePx(dpToPx(DEFAULT_THUMB_DP), save = true)
                return true
            }
        })
        var startY = 0f
        var startSize = 0
        handle.setOnTouchListener { v, e ->
            doubleTap.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = e.rawY
                    startSize = stripAdapter.itemSizePx
                    v.isPressed = true
                    sizeLabel.visibility = View.VISIBLE
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = startY - e.rawY
                    setThumbSizePx((startSize + dy).roundToInt(), save = false)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    sizeLabel.visibility = View.GONE
                    saveThumbSize()
                }
            }
            true
        }
    }

    private fun setThumbSizePx(px: Int, save: Boolean) {
        val clamped = px.coerceIn(dpToPx(MIN_THUMB_DP), dpToPx(MAX_THUMB_DP))
        stripAdapter.setItemSize(clamped)
        updateStripPadding()
        centerStrip(pager.currentItem, smooth = false)
        updateSizeLabel()
        if (save) saveThumbSize()
    }

    private fun saveThumbSize() {
        prefs.edit().putInt(PREF_THUMB_DP, pxToDp(stripAdapter.itemSizePx)).apply()
    }

    private fun updateSizeLabel() {
        sizeLabel.text = getString(R.string.size_format, pxToDp(stripAdapter.itemSizePx))
    }

    private fun showSizeDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_thumb_size, null)
        val seek = view.findViewById<SeekBar>(R.id.seek)
        val label = view.findViewById<TextView>(R.id.value)
        seek.max = MAX_THUMB_DP - MIN_THUMB_DP
        seek.progress = pxToDp(stripAdapter.itemSizePx) - MIN_THUMB_DP
        label.text = getString(R.string.size_format, seek.progress + MIN_THUMB_DP)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                val dp = progress + MIN_THUMB_DP
                label.text = getString(R.string.size_format, dp)
                if (stripContainer.visibility != View.VISIBLE) setStripVisible(true)
                setThumbSizePx(dpToPx(dp), save = false)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) = saveThumbSize()
        })
        AlertDialog.Builder(this)
            .setTitle(R.string.thumb_size_title)
            .setView(view)
            .setPositiveButton(R.string.done) { _, _ -> saveThumbSize() }
            .setNeutralButton(R.string.reset) { _, _ ->
                setThumbSizePx(dpToPx(DEFAULT_THUMB_DP), save = true)
            }
            .show()
    }

    /** Side padding so the first and last thumbnails can sit in the centre. */
    private fun updateStripPadding() {
        val pad = maxOf(0, (strip.width - stripAdapter.itemSizePx) / 2 - dpToPx(2))
        if (strip.paddingLeft != pad || strip.paddingRight != pad) {
            strip.setPadding(pad, strip.paddingTop, pad, strip.paddingBottom)
        }
    }

    private fun centerStrip(position: Int, smooth: Boolean) {
        if (position !in stripAdapter.items.indices || strip.width == 0) return
        if (smooth) {
            val scroller = object : LinearSmoothScroller(this) {
                override fun calculateDtToFit(
                    viewStart: Int, viewEnd: Int, boxStart: Int, boxEnd: Int, snapPreference: Int,
                ): Int = (boxStart + (boxEnd - boxStart) / 2) - (viewStart + (viewEnd - viewStart) / 2)
            }
            scroller.targetPosition = position
            stripLayout.startSmoothScroll(scroller)
        } else {
            // Offset is measured from the padded start edge.
            val offset = (strip.width - strip.paddingLeft - strip.paddingRight -
                stripAdapter.itemSizePx) / 2 - dpToPx(2)
            stripLayout.scrollToPositionWithOffset(position, offset)
        }
    }

    private fun setStripVisible(visible: Boolean, save: Boolean = true) {
        stripContainer.visibility = if (visible) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btn_toggle_strip).alpha = if (visible) 1f else 0.5f
        if (save) prefs.edit().putBoolean(PREF_STRIP_VISIBLE, visible).apply()
        if (visible) strip.post {
            updateStripPadding()
            centerStrip(pager.currentItem, smooth = false)
        }
    }

    // ---- Immersive toggle -------------------------------------------------

    private fun toggleUi() {
        uiVisible = !uiVisible
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (uiVisible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
            fade(topBar, true)
            fade(bottomPanel, true)
        } else {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            fade(topBar, false)
            fade(bottomPanel, false)
        }
    }

    private fun fade(v: View, show: Boolean) {
        v.animate().cancel()
        if (show) {
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(180).start()
        } else {
            v.animate().alpha(0f).setDuration(180).withEndAction { v.visibility = View.GONE }.start()
        }
    }

    private fun dpToPx(dp: Int) = (dp * resources.displayMetrics.density).roundToInt()
    private fun pxToDp(px: Int) = (px / resources.displayMetrics.density).roundToInt()
}
