# ThumbGallery

A lightweight Android photo gallery with a **resizable thumbnail strip** under the image viewer.

## Features

- Grid of all photos on the device, newest first. Pinch the grid (or use the ⋮ menu) to change the number of columns.
- Full-screen viewer: swipe between photos, pinch or double-tap to zoom, drag to pan.
- **Thumbnail strip at the bottom of the viewer**
  - **Drag the bar above the strip** up to make the thumbnails bigger, down to make them smaller (36–200 dp). Double-tap the bar to reset.
  - Or tap the sliders icon (top right) to set an exact size with a slider.
  - Tap a thumbnail to jump to it. The current photo is outlined and kept in the centre.
  - The film-strip icon shows or hides the strip.
  - Your size and on/off choice are saved.
- Tap a photo to hide everything for a clean full-screen view.
- Works with Android 14's "Select photos" limited access ("Choose more photos" in the menu).
- No third-party libraries, no internet permission. Needs Android 9 or newer.

## Build the APK

### Option A: GitHub (no PC software needed)
1. Create a new repository on github.com and upload **everything** in this folder, including the hidden `.github` folder and `gradle/wrapper/gradle-wrapper.jar`.
2. Open the repo's **Actions** tab. The "Build APK" workflow runs on every push (or press *Run workflow*).
3. When it finishes (about 3–5 min), open the run and download **ThumbGallery-apk**. Unzip it to get `app-debug.apk`.
4. On your phone, open the APK and allow "Install unknown apps" for your browser or file manager when prompted.

### Option B: Android Studio
1. Open this folder in Android Studio (File → Open).
2. Let Gradle sync, then choose **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
3. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

From a terminal with the Android SDK installed: `./gradlew assembleDebug`.

## Project layout

```
app/src/main/java/com/thumbgallery/app/
  MainActivity.kt       grid screen + permissions
  ViewerActivity.kt     full-screen viewer + resizable thumbnail strip
  Adapters.kt           grid, pager and strip adapters
  ZoomImageView.kt      pinch/double-tap zoom that plays nicely with swiping
  ImageLoader.kt        cached, background image decoding
  MediaRepository.kt    reads photos from MediaStore
```

To change the size limits or the default, edit `MIN_THUMB_DP`, `MAX_THUMB_DP` and `DEFAULT_THUMB_DP` in `ViewerActivity.kt`.
