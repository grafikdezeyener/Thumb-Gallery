package com.thumbgallery.app

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

/** Lists All photos, the user's collections and the device's folders. Tapping one opens it in the grid. */
class AlbumsActivity : AppCompatActivity() {

    sealed class Entry {
        data class Header(val title: String) : Entry()
        data class Tile(
            val key: String,
            val title: String,
            val count: Int,
            val cover: Uri?,
            val collectionId: String? = null,
        ) : Entry()
        object NewCollection : Entry()
    }

    private lateinit var adapter: EntryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_albums)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = getString(R.string.albums)
        toolbar.setNavigationIcon(R.drawable.ic_back)
        toolbar.setNavigationContentDescription(R.string.back)
        toolbar.setNavigationOnClickListener { finish() }

        val list = findViewById<RecyclerView>(R.id.list)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            toolbar.updatePadding(top = bars.top, left = bars.left, right = bars.right)
            list.updatePadding(left = bars.left + dp(8), right = bars.right + dp(8), bottom = bars.bottom + dp(8))
            insets
        }

        val columns = if (resources.configuration.screenWidthDp >= 600) 4 else 2
        adapter = EntryAdapter(
            currentKey = SourceSettings.currentKey(this),
            onOpen = { tile ->
                SourceSettings.set(this, tile.key, tile.title)
                finish()
            },
            onLongPress = { tile -> tile.collectionId?.let { showCollectionOptions(it, tile.title) } },
            onNewCollection = {
                CollectionDialogs.askName(this, R.string.new_collection, "") { name ->
                    CollectionStore.create(this, name)
                    load()
                }
            },
        )
        val lm = GridLayoutManager(this, columns)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int) =
                if (adapter.entries.getOrNull(position) is Entry.Header) columns else 1
        }
        list.layoutManager = lm
        list.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        thread {
            val all = MediaRepository.queryRaw(this)
            val byId = all.associateBy { it.id }
            val newest = all.maxByOrNull { it.dateMs }
            val entries = ArrayList<Entry>()
            entries.add(
                Entry.Tile(SourceSettings.ALL, getString(R.string.all_photos), all.size, newest?.uri)
            )

            entries.add(Entry.Header(getString(R.string.collections)))
            CollectionStore.all(this).forEach { c ->
                val present = c.photoIds.mapNotNull { byId[it] }
                entries.add(
                    Entry.Tile(
                        key = SourceSettings.collectionKey(c.id),
                        title = c.name,
                        count = present.size,
                        cover = present.lastOrNull()?.uri,
                        collectionId = c.id,
                    )
                )
            }
            entries.add(Entry.NewCollection)

            val albums = MediaRepository.queryAlbums(this)
            if (albums.isNotEmpty()) {
                entries.add(Entry.Header(getString(R.string.device_albums)))
                albums.forEach { a ->
                    entries.add(Entry.Tile(SourceSettings.albumKey(a.bucketId), a.name, a.count, a.coverUri))
                }
            }
            runOnUiThread { if (!isDestroyed) adapter.submit(entries) }
        }
    }

    private fun showCollectionOptions(id: String, name: String) {
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(arrayOf(getString(R.string.rename), getString(R.string.delete_collection))) { _, which ->
                if (which == 0) {
                    CollectionDialogs.askName(this, R.string.rename_collection, name) { newName ->
                        CollectionStore.rename(this, id, newName)
                        load()
                    }
                } else {
                    AlertDialog.Builder(this)
                        .setTitle(getString(R.string.delete_collection_title, name))
                        .setMessage(R.string.delete_collection_message)
                        .setPositiveButton(R.string.delete) { _, _ ->
                            CollectionStore.delete(this, id)
                            if (SourceSettings.currentKey(this) == SourceSettings.collectionKey(id)) {
                                SourceSettings.set(this, SourceSettings.ALL, getString(R.string.all_photos))
                                adapter.currentKey = SourceSettings.ALL
                            }
                            load()
                        }
                        .setNegativeButton(android.R.string.cancel, null)
                        .show()
                }
            }
            .show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---- Adapter -----------------------------------------------------------

    class EntryAdapter(
        var currentKey: String,
        private val onOpen: (Entry.Tile) -> Unit,
        private val onLongPress: (Entry.Tile) -> Unit,
        private val onNewCollection: () -> Unit,
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        companion object {
            private const val TYPE_HEADER = 0
            private const val TYPE_TILE = 1
        }

        var entries: List<Entry> = emptyList()
            private set

        class HeaderVH(val text: TextView) : RecyclerView.ViewHolder(text)
        class TileVH(v: View) : RecyclerView.ViewHolder(v) {
            val cover: ImageView = v.findViewById(R.id.cover)
            val icon: ImageView = v.findViewById(R.id.icon)
            val title: TextView = v.findViewById(R.id.title)
            val count: TextView = v.findViewById(R.id.count)
            val frame: View = v.findViewById(R.id.cover_frame)
        }

        @SuppressLint("NotifyDataSetChanged")
        fun submit(list: List<Entry>) {
            entries = list
            notifyDataSetChanged()
        }

        override fun getItemCount() = entries.size

        override fun getItemViewType(position: Int) =
            if (entries[position] is Entry.Header) TYPE_HEADER else TYPE_TILE

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            return if (viewType == TYPE_HEADER) {
                HeaderVH(inflater.inflate(R.layout.item_album_header, parent, false) as TextView)
            } else {
                TileVH(inflater.inflate(R.layout.item_album, parent, false))
            }
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val e = entries[position]) {
                is Entry.Header -> (holder as HeaderVH).text.text = e.title
                is Entry.Tile -> {
                    val h = holder as TileVH
                    val ctx = h.itemView.context
                    h.title.text = e.title
                    h.count.text = ctx.resources.getQuantityString(R.plurals.photo_count, e.count, e.count)
                    h.count.visibility = View.VISIBLE
                    h.frame.isSelected = e.key == currentKey
                    if (e.cover != null) {
                        h.icon.visibility = View.GONE
                        ImageLoader.loadThumbnail(h.cover, e.cover, 384)
                    } else {
                        h.cover.setTag(R.id.tag_image_key, null)
                        h.cover.setImageDrawable(null)
                        h.icon.setImageResource(R.drawable.ic_collection)
                        h.icon.visibility = View.VISIBLE
                    }
                    h.itemView.setOnClickListener { onOpen(e) }
                    h.itemView.setOnLongClickListener {
                        if (e.collectionId != null) { onLongPress(e); true } else false
                    }
                }
                Entry.NewCollection -> {
                    val h = holder as TileVH
                    h.title.setText(R.string.new_collection)
                    h.count.visibility = View.INVISIBLE
                    h.frame.isSelected = false
                    h.cover.setTag(R.id.tag_image_key, null)
                    h.cover.setImageDrawable(null)
                    h.icon.setImageResource(R.drawable.ic_add)
                    h.icon.visibility = View.VISIBLE
                    h.itemView.setOnClickListener { onNewCollection() }
                    h.itemView.setOnLongClickListener(null)
                }
            }
        }
    }
}
