package com.thumbgallery.app

import android.app.Activity
import android.text.InputType
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

object CollectionDialogs {

    /** Lets the user pick (or create) a collection and adds the photos to it. */
    fun addToCollection(activity: Activity, photoIds: List<Long>, onDone: () -> Unit = {}) {
        if (photoIds.isEmpty()) return
        val collections = CollectionStore.all(activity)
        val labels = collections.map { "${it.name}  (${it.photoIds.size})" } +
            activity.getString(R.string.new_collection_ellipsis)
        AlertDialog.Builder(activity)
            .setTitle(R.string.add_to_collection)
            .setItems(labels.toTypedArray()) { _, which ->
                if (which < collections.size) {
                    add(activity, collections[which], photoIds)
                    onDone()
                } else {
                    askName(activity, R.string.new_collection, "") { name ->
                        val c = CollectionStore.create(activity, name)
                        add(activity, c, photoIds)
                        onDone()
                    }
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun add(activity: Activity, c: UserCollection, photoIds: List<Long>) {
        val added = CollectionStore.addPhotos(activity, c.id, photoIds)
        val msg = if (added == 0) {
            activity.getString(R.string.already_in_collection, c.name)
        } else {
            activity.resources.getQuantityString(R.plurals.added_to_collection, added, added, c.name)
        }
        Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()
    }

    /** Text-input dialog used for creating and renaming collections. */
    fun askName(activity: Activity, titleRes: Int, initial: String, onName: (String) -> Unit) {
        val input = EditText(activity).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setSingleLine()
            setText(initial)
            setSelection(initial.length)
            hint = activity.getString(R.string.collection_name_hint)
        }
        val pad = (20 * activity.resources.displayMetrics.density).toInt()
        val container = FrameLayout(activity).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(activity)
            .setTitle(titleRes)
            .setView(container)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) onName(name)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
