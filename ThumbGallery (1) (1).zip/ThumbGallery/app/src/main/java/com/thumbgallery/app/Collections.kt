package com.thumbgallery.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * What the grid is showing. Stored as a short key:
 *   "all"            every photo
 *   "album:<id>"     a device folder (MediaStore bucket)
 *   "col:<id>"       one of the user's own collections
 */
object SourceSettings {
    const val ALL = "all"
    private const val PREFS = "settings"
    private const val KEY = "source_key"
    private const val TITLE = "source_title"

    fun albumKey(bucketId: Long) = "album:$bucketId"
    fun collectionKey(id: String) = "col:$id"
    fun collectionId(key: String): String? = if (key.startsWith("col:")) key.substring(4) else null
    fun bucketId(key: String): Long? =
        if (key.startsWith("album:")) key.substring(6).toLongOrNull() else null

    fun currentKey(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, ALL) ?: ALL

    fun set(context: Context, key: String, title: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, key).putString(TITLE, title).apply()
    }

    /** Display name for a source key. */
    fun title(context: Context, key: String): String {
        if (key == ALL) return context.getString(R.string.all_photos)
        collectionId(key)?.let { id ->
            return CollectionStore.get(context, id)?.name ?: context.getString(R.string.all_photos)
        }
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(TITLE, null)
            ?: context.getString(R.string.album)
    }
}

data class UserCollection(
    val id: String,
    val name: String,
    val photoIds: List<Long>,
)

/** The user's own collections, saved as JSON in the app's private storage. */
object CollectionStore {
    private const val FILE = "collections.json"

    private fun file(context: Context) = File(context.filesDir, FILE)

    @Synchronized
    fun all(context: Context): List<UserCollection> {
        val f = file(context)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ids = o.optJSONArray("photos") ?: JSONArray()
                UserCollection(
                    id = o.getString("id"),
                    name = o.optString("name"),
                    photoIds = (0 until ids.length()).map { ids.getLong(it) },
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun get(context: Context, id: String) = all(context).firstOrNull { it.id == id }

    @Synchronized
    private fun save(context: Context, list: List<UserCollection>) {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("name", c.name)
                    .put("photos", JSONArray(c.photoIds))
            )
        }
        try {
            file(context).writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun create(context: Context, name: String): UserCollection {
        val c = UserCollection(System.currentTimeMillis().toString(), name.trim(), emptyList())
        save(context, all(context) + c)
        return c
    }

    @Synchronized
    fun rename(context: Context, id: String, name: String) =
        save(context, all(context).map { if (it.id == id) it.copy(name = name.trim()) else it })

    @Synchronized
    fun delete(context: Context, id: String) =
        save(context, all(context).filterNot { it.id == id })

    /** Adds photos to the end of a collection, skipping ones already in it. Returns how many were added. */
    @Synchronized
    fun addPhotos(context: Context, id: String, photoIds: List<Long>): Int {
        var added = 0
        save(context, all(context).map { c ->
            if (c.id != id) c else {
                val existing = c.photoIds.toHashSet()
                val fresh = photoIds.filter { existing.add(it) }
                added = fresh.size
                c.copy(photoIds = c.photoIds + fresh)
            }
        })
        return added
    }

    @Synchronized
    fun removePhotos(context: Context, id: String, photoIds: Collection<Long>) {
        val remove = photoIds.toHashSet()
        save(context, all(context).map { c ->
            if (c.id == id) c.copy(photoIds = c.photoIds.filterNot { it in remove }) else c
        })
    }
}
