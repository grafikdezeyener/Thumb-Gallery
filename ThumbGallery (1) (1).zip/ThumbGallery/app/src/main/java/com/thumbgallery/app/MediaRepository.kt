package com.thumbgallery.app

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    /** Date taken if known, otherwise date added, in milliseconds. */
    val dateMs: Long,
    val sizeBytes: Long,
)

/** A device folder (MediaStore bucket) such as Camera or Screenshots. */
data class DeviceAlbum(
    val bucketId: Long,
    val name: String,
    val count: Int,
    val coverUri: Uri,
)

enum class SortMode {
    DATE_NEWEST, DATE_OLDEST, NAME_AZ, NAME_ZA, SIZE_LARGEST, SIZE_SMALLEST, CUSTOM
}

/** Persists the chosen sort mode and the manual (drag-to-arrange) order for each view. */
object SortSettings {
    private const val PREFS = "settings"
    private const val KEY_MODE = "sort_mode"
    private const val LEGACY_ORDER_FILE = "custom_order.txt"

    fun mode(context: Context): SortMode {
        val name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_MODE, null)
        return SortMode.entries.firstOrNull { it.name == name } ?: SortMode.DATE_NEWEST
    }

    fun setMode(context: Context, mode: SortMode) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_MODE, mode.name).apply()
    }

    private fun orderFile(context: Context, sourceKey: String) =
        File(context.filesDir, "order_" + sourceKey.replace(Regex("[^A-Za-z0-9]"), "_") + ".txt")

    fun customOrder(context: Context, sourceKey: String): List<Long> {
        var f = orderFile(context, sourceKey)
        if (!f.exists() && sourceKey == SourceSettings.ALL) {
            f = File(context.filesDir, LEGACY_ORDER_FILE) // order saved by the previous version
        }
        if (!f.exists()) return emptyList()
        return try {
            f.readText().split(',').mapNotNull { it.trim().toLongOrNull() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveCustomOrder(context: Context, sourceKey: String, ids: List<Long>) {
        try {
            orderFile(context, sourceKey).writeText(ids.joinToString(","))
        } catch (_: Exception) {
        }
    }
}

object MediaRepository {

    private val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    /** Images in the given view (all / album / collection), in the user's chosen order. Off main thread. */
    fun queryImages(context: Context, sourceKey: String): List<MediaItem> {
        val bucket = SourceSettings.bucketId(sourceKey)
        val colId = SourceSettings.collectionId(sourceKey)
        val raw = when {
            bucket != null -> queryRaw(
                context, "${MediaStore.Images.Media.BUCKET_ID} = ?", arrayOf(bucket.toString())
            )
            colId != null -> {
                val col = CollectionStore.get(context, colId) ?: return emptyList()
                val wanted = col.photoIds.toHashSet()
                queryRaw(context).filter { it.id in wanted }
            }
            else -> queryRaw(context)
        }
        return sort(context, raw, SortSettings.mode(context), sourceKey)
    }

    fun queryRaw(
        context: Context,
        selection: String? = null,
        args: Array<String>? = null,
    ): List<MediaItem> {
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.SIZE,
        )
        val result = ArrayList<MediaItem>()
        try {
            context.contentResolver.query(collection, projection, selection, args, null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val takenCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
                val addedCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val taken = if (c.isNull(takenCol)) 0L else c.getLong(takenCol)
                    val added = if (c.isNull(addedCol)) 0L else c.getLong(addedCol) * 1000L
                    result.add(
                        MediaItem(
                            id = id,
                            uri = ContentUris.withAppendedId(collection, id),
                            name = c.getString(nameCol) ?: "",
                            dateMs = if (taken > 0) taken else added,
                            sizeBytes = if (c.isNull(sizeCol)) 0L else c.getLong(sizeCol),
                        )
                    )
                }
            }
        } catch (_: SecurityException) {
            // Permission revoked while running.
        }
        return result
    }

    /** Device folders, most recently updated first. Off main thread. */
    fun queryAlbums(context: Context): List<DeviceAlbum> {
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.BUCKET_ID,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
        )
        data class Acc(val name: String, val cover: Uri, var count: Int)
        val buckets = LinkedHashMap<Long, Acc>()
        try {
            context.contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val bCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
                val nCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                while (c.moveToNext()) {
                    if (c.isNull(bCol)) continue
                    val bucket = c.getLong(bCol)
                    val acc = buckets[bucket]
                    if (acc == null) {
                        buckets[bucket] = Acc(
                            name = c.getString(nCol) ?: "Unnamed",
                            cover = ContentUris.withAppendedId(collection, c.getLong(idCol)),
                            count = 1,
                        )
                    } else {
                        acc.count++
                    }
                }
            }
        } catch (_: SecurityException) {
        }
        return buckets.map { (id, a) -> DeviceAlbum(id, a.name, a.count, a.cover) }
    }

    private fun sort(
        context: Context, list: List<MediaItem>, mode: SortMode, sourceKey: String,
    ): List<MediaItem> {
        val byName = String.CASE_INSENSITIVE_ORDER
        return when (mode) {
            SortMode.DATE_NEWEST ->
                list.sortedWith(compareByDescending<MediaItem> { it.dateMs }.thenByDescending { it.id })
            SortMode.DATE_OLDEST ->
                list.sortedWith(compareBy<MediaItem> { it.dateMs }.thenBy { it.id })
            SortMode.NAME_AZ ->
                list.sortedWith(compareBy(byName) { it.name })
            SortMode.NAME_ZA ->
                list.sortedWith(compareByDescending(byName) { it.name })
            SortMode.SIZE_LARGEST ->
                list.sortedWith(compareByDescending<MediaItem> { it.sizeBytes }.thenByDescending { it.dateMs })
            SortMode.SIZE_SMALLEST ->
                list.sortedWith(compareBy<MediaItem> { it.sizeBytes }.thenByDescending { it.dateMs })
            SortMode.CUSTOM -> {
                val index = HashMap<Long, Int>()
                SortSettings.customOrder(context, sourceKey).forEachIndexed { i, id -> index[id] = i }
                val (known, fresh) = list.partition { it.id in index }
                // Photos added after you arranged go first, newest on top.
                fresh.sortedByDescending { it.dateMs } + known.sortedBy { index[it.id] }
            }
        }
    }
}
