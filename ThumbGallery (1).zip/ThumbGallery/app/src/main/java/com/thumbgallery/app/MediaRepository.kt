package com.thumbgallery.app

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    /** Date taken if known, otherwise date added, in milliseconds. */
    val dateMs: Long,
    val sizeBytes: Long,
)

enum class SortMode {
    DATE_NEWEST, DATE_OLDEST, NAME_AZ, NAME_ZA, SIZE_LARGEST, SIZE_SMALLEST, CUSTOM
}

/** Persists the chosen sort mode and the manual (drag-to-arrange) order. */
object SortSettings {
    private const val PREFS = "settings"
    private const val KEY_MODE = "sort_mode"
    private const val ORDER_FILE = "custom_order.txt"

    fun mode(context: Context): SortMode {
        val name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_MODE, null)
        return SortMode.entries.firstOrNull { it.name == name } ?: SortMode.DATE_NEWEST
    }

    fun setMode(context: Context, mode: SortMode) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_MODE, mode.name).apply()
    }

    fun customOrder(context: Context): List<Long> {
        val f = File(context.filesDir, ORDER_FILE)
        if (!f.exists()) return emptyList()
        return try {
            f.readText().split(',').mapNotNull { it.trim().toLongOrNull() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveCustomOrder(context: Context, ids: List<Long>) {
        try {
            File(context.filesDir, ORDER_FILE).writeText(ids.joinToString(","))
        } catch (_: Exception) {
        }
    }
}

object MediaRepository {

    /** Returns every image the app can see, in the user's chosen order. Call off the main thread. */
    fun queryImages(context: Context): List<MediaItem> =
        sort(context, queryRaw(context), SortSettings.mode(context))

    private fun queryRaw(context: Context): List<MediaItem> {
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.SIZE,
        )
        val result = ArrayList<MediaItem>()
        try {
            context.contentResolver.query(collection, projection, null, null, null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val takenCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
                val addedCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val taken = if (c.isNull(takenCol)) 0L else c.getLong(takenCol)
                    val added = if (c.isNull(addedCol)) 0L else c.getLong(addedCol) * 1000L
                    result.add(
                        MediaItem(
                            id = id,
                            uri = ContentUris.withAppendedId(collection, id),
                            name = c.getString(nameCol) ?: "",
                            dateMs = if (taken > 0) taken else added,
                            sizeBytes = if (c.isNull(sizeCol)) 0L else c.getLong(sizeCol),
                        )
                    )
                }
            }
        } catch (_: SecurityException) {
            // Permission revoked while running.
        }
        return result
    }

    private fun sort(context: Context, list: List<MediaItem>, mode: SortMode): List<MediaItem> {
        val byName = String.CASE_INSENSITIVE_ORDER
        return when (mode) {
            SortMode.DATE_NEWEST ->
                list.sortedWith(compareByDescending<MediaItem> { it.dateMs }.thenByDescending { it.id })
            SortMode.DATE_OLDEST ->
                list.sortedWith(compareBy<MediaItem> { it.dateMs }.thenBy { it.id })
            SortMode.NAME_AZ ->
                list.sortedWith(compareBy(byName) { it.name })
            SortMode.NAME_ZA ->
                list.sortedWith(compareByDescending(byName) { it.name })
            SortMode.SIZE_LARGEST ->
                list.sortedWith(compareByDescending<MediaItem> { it.sizeBytes }.thenByDescending { it.dateMs })
            SortMode.SIZE_SMALLEST ->
                list.sortedWith(compareBy<MediaItem> { it.sizeBytes }.thenByDescending { it.dateMs })
            SortMode.CUSTOM -> {
                val index = HashMap<Long, Int>()
                SortSettings.customOrder(context).forEachIndexed { i, id -> index[id] = i }
                val (known, fresh) = list.partition { it.id in index }
                // Photos added after you arranged go first, newest on top.
                fresh.sortedByDescending { it.dateMs } + known.sortedBy { index[it.id] }
            }
        }
    }
}
