package com.thumbgallery.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PREF_COLUMNS = "grid_columns"
        private const val MIN_COLUMNS = 2
        private const val MAX_COLUMNS = 7
        private const val DEFAULT_COLUMNS = 3
    }

    private enum class Mode { BROWSE, SELECT, ARRANGE }

    private lateinit var toolbar: Toolbar
    private lateinit var grid: RecyclerView
    private lateinit var emptyView: View
    private lateinit var emptyText: TextView
    private lateinit var emptyButton: Button
    private lateinit var adapter: GridAdapter
    private lateinit var layoutManager: GridLayoutManager

    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var askedOnce = false
    private var loading = false
    private var mode = Mode.BROWSE

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            askedOnce = true
            refresh()
        }

    private val deleter = MediaDeleter(this) { deleted ->
        if (deleted) {
            Toast.makeText(this, R.string.deleted, Toast.LENGTH_SHORT).show()
            setMode(Mode.BROWSE)
        }
        refresh()
    }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            if (mode == Mode.ARRANGE) cancelArrange() else setMode(Mode.BROWSE)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener { backCallback.handleOnBackPressed() }
        onBackPressedDispatcher.addCallback(this, backCallback)

        grid = findViewById(R.id.grid)
        emptyView = findViewById(R.id.empty_view)
        emptyText = findViewById(R.id.empty_text)
        emptyButton = findViewById(R.id.empty_button)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            toolbar.updatePadding(top = bars.top, left = bars.left, right = bars.right)
            grid.updatePadding(left = bars.left, right = bars.right, bottom = bars.bottom)
            insets
        }

        adapter = GridAdapter(
            onClick = { position -> onItemClick(position) },
            onLongClick = { position -> onItemLongClick(position) },
        )
        layoutManager = GridLayoutManager(this, prefs.getInt(PREF_COLUMNS, DEFAULT_COLUMNS))
        grid.layoutManager = layoutManager
        grid.adapter = adapter
        grid.setHasFixedSize(true)
        grid.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateDecodeSize() }
        setupPinchToResize()
        setupDragToArrange()

        emptyButton.setOnClickListener { onGrantClicked() }

        if (!hasPermission()) requestPermission()
    }

    override fun onResume() {
        super.onResume()
        refresh() // picks up new photos and permission changes made in Settings
    }

    // ---- Item clicks -------------------------------------------------------

    private fun onItemClick(position: Int) {
        when (mode) {
            Mode.SELECT -> {
                adapter.toggle(position)
                if (adapter.selectedIds.isEmpty()) setMode(Mode.BROWSE) else updateTitle()
            }
            Mode.ARRANGE -> Unit
            Mode.BROWSE -> {
                val item = adapter.items[position]
                startActivity(
                    Intent(this, ViewerActivity::class.java)
                        .putExtra(ViewerActivity.EXTRA_ID, item.id)
                        .putExtra(ViewerActivity.EXTRA_POSITION, position)
                )
            }
        }
    }

    private fun onItemLongClick(position: Int): Boolean {
        if (mode == Mode.ARRANGE) return false // ItemTouchHelper handles the drag
        if (mode == Mode.BROWSE) setMode(Mode.SELECT)
        adapter.toggle(position)
        if (adapter.selectedIds.isEmpty()) setMode(Mode.BROWSE) else updateTitle()
        return true
    }

    // ---- Modes -------------------------------------------------------------

    private fun setMode(newMode: Mode) {
        mode = newMode
        adapter.selectionMode = newMode == Mode.SELECT
        backCallback.isEnabled = newMode != Mode.BROWSE
        if (newMode == Mode.BROWSE) {
            toolbar.navigationIcon = null
        } else {
            toolbar.setNavigationIcon(R.drawable.ic_close)
            toolbar.setNavigationContentDescription(android.R.string.cancel)
        }
        updateTitle()
        invalidateOptionsMenu()
    }

    private fun updateTitle() {
        supportActionBar?.title = when (mode) {
            Mode.BROWSE -> getString(R.string.app_name)
            Mode.SELECT -> getString(R.string.selected_count, adapter.selectedIds.size)
            Mode.ARRANGE -> getString(R.string.arrange_title)
        }
    }

    private fun finishArrange() {
        SortSettings.saveCustomOrder(this, adapter.items.map { it.id })
        SortSettings.setMode(this, SortMode.CUSTOM)
        setMode(Mode.BROWSE)
        Toast.makeText(this, R.string.order_saved, Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun cancelArrange() {
        setMode(Mode.BROWSE)
        refresh()
    }

    private fun setupDragToArrange() {
        val callback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun isLongPressDragEnabled() = mode == Mode.ARRANGE

            override fun onMove(
                rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder,
            ): Boolean {
                adapter.move(vh.bindingAdapterPosition, target.bindingAdapterPosition)
                return true
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) = Unit

            override fun onSelectedChanged(vh: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(vh, actionState)
                if (actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
                    vh?.itemView?.animate()?.scaleX(1.08f)?.scaleY(1.08f)?.alpha(0.85f)
                        ?.setDuration(120)?.start()
                }
            }

            override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(rv, vh)
                vh.itemView.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start()
            }
        }
        ItemTouchHelper(callback).attachToRecyclerView(grid)
    }

    // ---- Permissions -------------------------------------------------------

    private fun permissionsToRequest(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
        )
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun hasPermission() = permissionsToRequest().any { granted(it) }

    private fun hasPartialAccessOnly() = Build.VERSION.SDK_INT >= 34 &&
        !granted(Manifest.permission.READ_MEDIA_IMAGES) &&
        granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)

    private fun requestPermission() = permissionLauncher.launch(permissionsToRequest())

    private fun onGrantClicked() {
        val canAsk = permissionsToRequest().any { shouldShowRequestPermissionRationale(it) }
        if (askedOnce && !canAsk && !hasPermission()) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.fromParts("package", packageName, null))
            )
        } else {
            requestPermission()
        }
    }

    // ---- Loading -----------------------------------------------------------

    private fun refresh() {
        if (mode == Mode.ARRANGE) return // don't undo the user's dragging
        invalidateOptionsMenu()
        if (!hasPermission()) {
            adapter.submit(emptyList())
            showEmpty(getString(R.string.permission_needed), getString(R.string.grant_access))
            return
        }
        if (loading) return
        loading = true
        thread {
            val list = MediaRepository.queryImages(this)
            runOnUiThread {
                loading = false
                if (isDestroyed || mode == Mode.ARRANGE) return@runOnUiThread
                if (list != adapter.items) adapter.submit(list)
                if (mode == Mode.SELECT) {
                    if (adapter.selectedIds.isEmpty()) setMode(Mode.BROWSE) else updateTitle()
                }
                if (list.isEmpty()) {
                    showEmpty(getString(R.string.no_images), null)
                } else {
                    emptyView.visibility = View.GONE
                    grid.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun showEmpty(message: String, button: String?) {
        grid.visibility = View.GONE
        emptyView.visibility = View.VISIBLE
        emptyText.text = message
        emptyButton.visibility = if (button == null) View.GONE else View.VISIBLE
        if (button != null) emptyButton.text = button
    }

    // ---- Grid size ---------------------------------------------------------

    private fun setColumns(count: Int) {
        val c = count.coerceIn(MIN_COLUMNS, MAX_COLUMNS)
        if (c == layoutManager.spanCount) return
        layoutManager.spanCount = c
        prefs.edit().putInt(PREF_COLUMNS, c).apply()
        updateDecodeSize()
        adapter.notifyItemRangeChanged(0, adapter.itemCount)
    }

    private fun updateDecodeSize() {
        val w = grid.width
        if (w == 0) return
        val cell = w / layoutManager.spanCount
        adapter.decodePx = (((cell + 127) / 128) * 128).coerceIn(128, 512)
    }

    private fun setupPinchToResize() {
        var accumulated = 1f
        val detector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                    accumulated = 1f
                    return true
                }

                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    accumulated *= detector.scaleFactor
                    if (accumulated > 1.25f) {
                        setColumns(layoutManager.spanCount - 1); accumulated = 1f
                    } else if (accumulated < 0.8f) {
                        setColumns(layoutManager.spanCount + 1); accumulated = 1f
                    }
                    return true
                }
            })
        grid.addOnItemTouchListener(object : RecyclerView.SimpleOnItemTouchListener() {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                detector.onTouchEvent(e)
                return e.pointerCount > 1
            }

            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
                detector.onTouchEvent(e)
            }
        })
    }

    // ---- Menu --------------------------------------------------------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        when (mode) {
            Mode.BROWSE -> {
                menuInflater.inflate(R.menu.main_menu, menu)
                menu.findItem(R.id.action_select_more)?.isVisible = hasPartialAccessOnly()
                val checkedId = when (SortSettings.mode(this)) {
                    SortMode.DATE_NEWEST -> R.id.sort_date_newest
                    SortMode.DATE_OLDEST -> R.id.sort_date_oldest
                    SortMode.NAME_AZ -> R.id.sort_name_az
                    SortMode.NAME_ZA -> R.id.sort_name_za
                    SortMode.SIZE_LARGEST -> R.id.sort_size_largest
                    SortMode.SIZE_SMALLEST -> R.id.sort_size_smallest
                    SortMode.CUSTOM -> R.id.sort_custom
                }
                menu.findItem(checkedId)?.isChecked = true
            }
            Mode.SELECT -> menuInflater.inflate(R.menu.selection_menu, menu)
            Mode.ARRANGE -> menuInflater.inflate(R.menu.arrange_menu, menu)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val sort = when (item.itemId) {
            R.id.sort_date_newest -> SortMode.DATE_NEWEST
            R.id.sort_date_oldest -> SortMode.DATE_OLDEST
            R.id.sort_name_az -> SortMode.NAME_AZ
            R.id.sort_name_za -> SortMode.NAME_ZA
            R.id.sort_size_largest -> SortMode.SIZE_LARGEST
            R.id.sort_size_smallest -> SortMode.SIZE_SMALLEST
            R.id.sort_custom -> SortMode.CUSTOM
            else -> null
        }
        if (sort != null) {
            SortSettings.setMode(this, sort)
            item.isChecked = true
            refresh()
            grid.scrollToPosition(0)
            return true
        }
        return when (item.itemId) {
            R.id.action_select -> { setMode(Mode.SELECT); true }
            R.id.action_arrange -> {
                if (adapter.itemCount > 0) {
                    setMode(Mode.ARRANGE)
                    Toast.makeText(this, R.string.arrange_hint, Toast.LENGTH_LONG).show()
                }
                true
            }
            R.id.action_select_all -> { adapter.selectAll(); updateTitle(); true }
            R.id.action_delete -> {
                deleter.delete(adapter.selectedItems().map { it.uri })
                true
            }
            R.id.action_done -> { finishArrange(); true }
            R.id.action_bigger -> { setColumns(layoutManager.spanCount - 1); true }
            R.id.action_smaller -> { setColumns(layoutManager.spanCount + 1); true }
            R.id.action_select_more -> { requestPermission(); true }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
