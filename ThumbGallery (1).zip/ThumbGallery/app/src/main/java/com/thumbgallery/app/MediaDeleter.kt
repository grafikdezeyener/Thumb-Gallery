package com.thumbgallery.app

import android.Manifest
import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat

/**
 * Deletes images the right way for each Android version:
 *  - Android 11+: the system's own "Allow ThumbGallery to delete N photos?" dialog.
 *  - Android 10: our confirm dialog, then the system's per-photo permission prompt if needed.
 *  - Android 9: our confirm dialog plus the storage write permission.
 *
 * Must be created while the activity is being constructed (e.g. as a property).
 */
class MediaDeleter(
    private val activity: ComponentActivity,
    private val onFinished: (deletedAny: Boolean) -> Unit,
) {
    private var pending: List<Uri> = emptyList()
    private var deletedSome = false

    private val systemPrompt = activity.registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        val ok = result.resultCode == Activity.RESULT_OK
        if (Build.VERSION.SDK_INT >= 30) {
            onFinished(ok)
        } else if (ok) {
            deleteOneByOne(pending) // Android 10: retry now that access was granted
        } else {
            onFinished(deletedSome)
        }
    }

    private val writePermission = activity.registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            deleteOneByOne(pending)
        } else {
            Toast.makeText(activity, R.string.delete_permission_denied, Toast.LENGTH_LONG).show()
            onFinished(false)
        }
    }

    fun delete(uris: List<Uri>) {
        if (uris.isEmpty()) return
        pending = uris
        deletedSome = false
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(activity.contentResolver, uris)
                systemPrompt.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) {
                Toast.makeText(activity, R.string.delete_failed, Toast.LENGTH_LONG).show()
                onFinished(false)
            }
            return
        }
        AlertDialog.Builder(activity)
            .setTitle(activity.resources.getQuantityString(R.plurals.delete_title, uris.size, uris.size))
            .setMessage(R.string.delete_message)
            .setPositiveButton(R.string.delete) { _, _ -> startLegacyDelete() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun startLegacyDelete() {
        if (Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            writePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            deleteOneByOne(pending)
        }
    }

    private fun deleteOneByOne(uris: List<Uri>) {
        for ((i, uri) in uris.withIndex()) {
            try {
                if (activity.contentResolver.delete(uri, null, null) > 0) deletedSome = true
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    pending = uris.subList(i, uris.size).toList()
                    systemPrompt.launch(
                        IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build()
                    )
                    return
                }
                Toast.makeText(activity, R.string.delete_failed, Toast.LENGTH_LONG).show()
                break
            } catch (_: Exception) {
                // Skip files that vanished or can't be removed.
            }
        }
        pending = emptyList()
        onFinished(deletedSome)
    }
}
